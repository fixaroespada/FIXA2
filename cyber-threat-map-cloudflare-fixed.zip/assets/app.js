const $ = id => document.getElementById(id);
const map = L.map('map', { zoomControl: true, worldCopyJump: true, minZoom: 2 }).setView([24, 8], 2);
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { subdomains: 'abcd', maxZoom: 19, attribution: '&copy; OpenStreetMap &copy; CARTO' }).addTo(map);
let markerLayer = L.layerGroup().addTo(map), allRecords = [], activeFilter = 'all', lastUpdate = null;
const colors = { feodo: 'red', sslbl: 'amber', blocklist: 'blue' };
function fmtTime(value) { if (!value) return 'RECENT'; const d = new Date(value); return Number.isNaN(+d) ? String(value).slice(0, 16) : d.toISOString().replace('T',' ').slice(0,16)+' UTC'; }
function renderEvents() {
  const rows = activeFilter === 'all' ? allRecords : allRecords.filter(x => x.source === activeFilter);
  $('event-count').textContent = rows.length;
  $('events').innerHTML = rows.length ? rows.slice(0, 50).map(x => `<article class="event" data-ip="${x.ip}"><div class="event-top"><span class="event-source ${x.type === 'feodo' ? 'feodo' : x.type === 'blocklist' ? 'block' : ''}">${x.source.toUpperCase()}</span><span class="event-time">${fmtTime(x.firstSeen)}</span></div><div class="event-ip">${x.ip}${x.port ? ':'+x.port : ''}</div><div class="event-meta"><span>${x.city ? x.city+', ' : ''}${x.country || 'GEOLOCATION PENDING'}</span><span class="event-malware">${x.malware || 'Threat indicator'}</span></div></article>`).join('') : '<div class="empty-state">No indicators available for this source at the moment.</div>';
  document.querySelectorAll('.event').forEach(el => el.addEventListener('click', () => { const x = allRecords.find(r => r.ip === el.dataset.ip); if (x?.lat != null) { map.setView([x.lat,x.lon], 6); markerLayer.eachLayer(m => { if (m.options.ip === x.ip) m.openPopup(); }); } else toast('No geolocation available for this IP.'); }));
}
function renderMap() {
  markerLayer.clearLayers();
  const rows = allRecords.filter(x => x.lat != null && x.lon != null && (activeFilter === 'all' || x.source === activeFilter));
  rows.forEach(x => {
    const cls = colors[x.type] || 'blue';
    const icon = L.divIcon({ className: '', html: `<div class="threat-marker ${cls}"></div>`, iconSize: [12,12], iconAnchor: [6,6] });
    L.marker([x.lat,x.lon], { icon, ip: x.ip }).bindPopup(`<b>${x.ip}</b><br>${x.source}<br>${x.malware || 'Threat indicator'}<br>${x.city || ''}${x.country ? ', '+x.country : ''}<br><small>Approximate IP location · not attack origin proof</small>`).addTo(markerLayer);
  });
  $('map-count').textContent = `${rows.length} INDICATORS PLOTTED`;
}
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2600); }
function updateSourceCards(sources) { $('source-grid').innerHTML = sources.map(s => `<article class="source-card"><span class="source-icon">${s.name === 'Feodo Tracker' ? '◉' : s.name === 'SSLBL' ? '◇' : '⌁'}</span><div><b>${s.name}</b><small>${s.name === 'Feodo Tracker' ? 'Botnet command & control IPs' : s.name === 'SSLBL' ? 'Malicious SSL / botnet C2 IPs' : 'Recently reported hostile IPs'}</small></div><span class="source-state" style="color:${s.status === 'ONLINE' ? 'var(--green)' : 'var(--red)'}">${s.status} · ${s.count}</span></article>`).join(''); }
async function refresh() {
  $('connection-label').textContent = 'FETCHING PUBLIC THREAT FEEDS'; $('metric-status').textContent = 'SYNCING';
  try {
    const r = await fetch('/api/threats', { cache: 'no-store' }); if (!r.ok) throw new Error(`API ${r.status}`);
    const data = await r.json(); allRecords = data.records || []; lastUpdate = new Date(data.generatedAt);
    $('metric-total').textContent = allRecords.length.toLocaleString();
    $('metric-countries').textContent = new Set(allRecords.map(x => x.country).filter(Boolean)).size;
    $('metric-sources').textContent = (data.sources || []).filter(x => x.status === 'ONLINE').length;
    $('metric-status').textContent = data.sources?.some(x => x.status === 'ONLINE') ? 'OPERATIONAL' : 'DEGRADED';
    $('metric-status').style.color = data.sources?.some(x => x.status === 'ONLINE') ? 'var(--green)' : 'var(--amber)';
    $('last-sync').textContent = lastUpdate.toISOString().replace('T',' ').slice(0,19)+' UTC';
    $('connection-label').textContent = data.sources?.some(x => x.status === 'ONLINE') ? 'INTELLIGENCE FEEDS CONNECTED' : 'PARTIAL FEED CONNECTIVITY';
    $('age').textContent = 'just now';
    updateSourceCards(data.sources || []); renderEvents(); renderMap();
    if (!allRecords.length) toast('Feeds responded but currently returned no indicators.');
  } catch (e) {
    $('connection-label').textContent = 'FEED CONNECTION ERROR'; $('metric-status').textContent = 'OFFLINE'; $('metric-status').style.color = 'var(--red)';
    $('events').innerHTML = `<div class="empty-state">Unable to load live intelligence.<br>${e.message}<br>Check the Pages Function deployment and feed availability.</div>`;
    toast('Could not load threat feeds.');
  }
}
document.querySelectorAll('.filter').forEach(btn => btn.addEventListener('click', () => { document.querySelectorAll('.filter').forEach(b => b.classList.remove('active')); btn.classList.add('active'); activeFilter = btn.dataset.filter === 'all' ? 'all' : btn.dataset.filter; renderEvents(); renderMap(); }));
$('refresh').addEventListener('click', () => { refresh(); toast('Refreshing threat intelligence…'); });
$('reset-view').addEventListener('click', () => map.setView([24,8],2));
$('fullscreen').addEventListener('click', async () => { if (!document.fullscreenElement) await document.documentElement.requestFullscreen?.(); else await document.exitFullscreen?.(); });
function clock() { $('clock').textContent = new Date().toISOString().slice(11,19)+' UTC'; if (lastUpdate) $('age').textContent = Math.max(0,Math.floor((Date.now()-lastUpdate)/60000))+'m ago'; }
clock(); setInterval(clock,1000); refresh(); setInterval(refresh,300000);
