const FEEDS = [
  { name: 'Feodo Tracker', url: 'https://feodotracker.abuse.ch/downloads/ipblocklist.json', type: 'feodo' },
  { name: 'SSLBL', url: 'https://sslbl.abuse.ch/blacklist/sslipblacklist.csv', type: 'sslbl' },
  { name: 'Blocklist.de', url: 'https://lists.blocklist.de/lists/all.txt', type: 'blocklist' }
];
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'public, max-age=60, s-maxage=300', 'access-control-allow-origin': '*' } });
function validIPv4(ip) { return /^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$/.test(ip); }
function parseCSV(text) {
  return text.split(/\r?\n/).filter(l => l && !l.startsWith('#') && !l.startsWith('"#')).map(line => line.split(',').map(v => v.replace(/^"|"$/g, '').trim()));
}
async function fetchFeed(feed) {
  try {
    const r = await fetch(feed.url, { headers: { 'user-agent': 'ThreatAtlas-CommunityDashboard/1.0' }, cf: { cacheTtl: 300, cacheEverything: true } });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const body = await r.text();
    if (feed.type === 'feodo') {
      const rows = JSON.parse(body);
      return rows.filter(x => validIPv4(x.ip_address || '')).map(x => ({ ip: x.ip_address, port: x.port || '', source: feed.name, type: 'feodo', malware: x.malware || 'Botnet C2', status: x.status || 'Listed', firstSeen: x.first_seen || '', country: x.country || '', asn: x.as_number || '', org: x.as_name || '' }));
    }
    if (feed.type === 'sslbl') {
      return parseCSV(body).filter(row => validIPv4(row[1] || '')).map(row => ({ ip: row[1], port: row[2] || '', source: feed.name, type: 'sslbl', malware: 'Malicious SSL / C2', firstSeen: row[0] || '' }));
    }
    return body.split(/\r?\n/).map(s => s.trim()).filter(validIPv4).map(ip => ({ ip, source: feed.name, type: 'blocklist', malware: 'Reported hostile IP' }));
  } catch (e) { return { error: e.message, name: feed.name }; }
}
export async function onRequestGet() {
  const results = await Promise.all(FEEDS.map(fetchFeed));
  const errors = results.filter(x => !Array.isArray(x));
  let records = results.filter(Array.isArray).flat();
  const unique = new Map();
  for (const item of records) if (!unique.has(item.ip)) unique.set(item.ip, item);
  records = [...unique.values()].slice(0, 60);
  // Enrich a bounded number of IPs; locations are approximate and are not attack origins.
  const toLocate = records.filter(x => !x.country || !x.lat).slice(0, 24);
  const geo = await Promise.all(toLocate.map(async item => {
    try {
      const r = await fetch(`https://ipwho.is/${encodeURIComponent(item.ip)}`, { cf: { cacheTtl: 21600, cacheEverything: true } });
      if (!r.ok) return null;
      const d = await r.json();
      if (!d.success || !Number.isFinite(d.latitude) || !Number.isFinite(d.longitude)) return null;
      return { ip: item.ip, country: d.country || '', countryCode: d.country_code || '', city: d.city || '', lat: d.latitude, lon: d.longitude, org: item.org || d.connection?.isp || '', asn: item.asn || d.connection?.asn || '' };
    } catch { return null; }
  }));
  const geoMap = new Map(geo.filter(Boolean).map(x => [x.ip, x]));
  records = records.map(item => ({ ...item, ...(geoMap.get(item.ip) || {}), lat: item.lat ?? null, lon: item.lon ?? null }));
  const sources = FEEDS.map((f, i) => ({ name: f.name, status: Array.isArray(results[i]) ? 'ONLINE' : 'UNAVAILABLE', count: Array.isArray(results[i]) ? results[i].length : 0, error: Array.isArray(results[i]) ? '' : results[i].error }));
  return json({ generatedAt: new Date().toISOString(), records, sources, errors: errors.map(x => ({ source: x.name, error: x.error })), note: 'Feed indicators represent reported malicious infrastructure, not confirmed live attacks. IP geolocation is approximate.' });
}
